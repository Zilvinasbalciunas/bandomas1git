import UIKit

var greeting = "Hello, playground"
print (greeting)
var sveikinimas = "hello hello"
print ( sveikinimas)

